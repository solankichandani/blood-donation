<?php 
include("security.php");
require "config.php";
if(isset($_POST['adminm']))
{
	$adm = $_POST['adminm'];
	$password = $_POST['pwd'];
	$sql="SELECT * FROM `admin` WHERE admin_name = '$adm'  and	password = '$password' ";
	$result = mysqli_query($con,$sql);
	if(mysqli_fetch_array($result))
	{
		$_SESSION['admin']=$adm;
	}
		

}