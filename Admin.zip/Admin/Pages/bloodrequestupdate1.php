<?php
require "config.php";
if(isset($_REQUEST['no']))
{	
	$no=$_REQUEST['no'];
	$nm=$_REQUEST['name'];
	$date=$_REQUEST['date'];
	$acc=$_REQUEST['account'];
	$bags=$_REQUEST['bags'];
	$amt=$_REQUEST['amt'];
	$pus=$_REQUEST['purpose'];
	$rem=$_REQUEST['remark'];
	echo $update="UPDATE `request` SET `patient_name`='$nm',`date_request`='$date',`blood_type`='$acc',`bags`='$bags',`amout`='$amt',`purpose`='$pus',`remark`='$rem' WHERE req_id=$no";
	mysqli_query($con,$update);
	header("location:bloodrequest.php");
	}
?>
