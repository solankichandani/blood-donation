<?php
	require "config.php";
	 $id=$_GET['id'];
		$sql="DELETE FROM `message` WHERE id='$id'";
		mysqli_query($con,$sql);
		header("location:message.php");
?>

