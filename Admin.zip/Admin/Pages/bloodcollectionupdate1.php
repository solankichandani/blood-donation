<?php
require "config.php";														
if(isset($_REQUEST['update_btn']))
{
	$don=$_REQUEST['donorid'];
	$hos=$_REQUEST['hospital'];
	$bags=$_REQUEST['bags'];
	$date=$_REQUEST['date'];
	$inch=$_REQUEST['incharge'];
	echo $update="UPDATE `collection` SET `hospital`='$hos',`bags`='$bags',`date`='$date',`incharge`='$inch' WHERE donorid=$don";
	mysqli_query($con,$update);
}
?>