<!doctype html>
<html class="no-js" lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Blood Bank Management System|</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="">
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- adminpro icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
        ============================================ -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- data-table CSS
        ============================================ -->
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- charts C3 CSS
        ============================================ -->
    <link rel="stylesheet" href="css/c3.min.css">
    <!-- forms CSS
        ============================================ -->
    <link rel="stylesheet" href="css/form/all-type-forms.css">
    <!-- switcher CSS
        ============================================ -->
    <link rel="stylesheet" href="css/switcher/color-switcher.css">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
        ============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- Color Css Files
        ============================================ -->
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-one.css" title="color-one" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-two.css" title="color-two" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-three.css" title="color-three" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-four.css" title="color-four" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-five.css" title="color-five" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-six.css" title="color-six" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-seven.css" title="color-seven" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-eight.css" title="color-eight" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-nine.css" title="color-nine" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="css/switcher/color-ten.css" title="color-ten" media="screen" />
</head>

<body>
<?php
	
	/*session_start();
	if(!$_SESSION['admin'])
	{
		header("location:index.php");
	}
	$con = mysqli_connect("localhost","root","","blood");
	if(!$con)
	{
		echo "Error DB!";
	}
	
	else
	{
		$oldmail = $_SESSION['admin'];
		$sql = "SELECT * from `admin` where admin_name='$oldmail'";
		$res = mysqli_query($con,$sql);
	}*/
?>

   <?php
		require "header.php";
   ?>
    <!-- Main Menu area start-->
    <div class="main-menu-area mg-tb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs custom-menu-wrap">
                        <li class="active"><a  href="dashboard.php">Dashboard</a>
                        </li>
                        <li><a href="donor.php">Donor</a>
                        </li>
						
						<li><a href="bloodcollection.php">Blood Collection</a>
						</li>
                        <li><a href="bloodrequest.php">Blood Request</a>
                        </li>
                        <li><a href="bloodissued.php">Blood Issued</a>
                        </li>
						<li><a href="message.php">Message</a>
						 </li>
                        <li><a href="useraccount.php">User Accounts</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->
	
 <!-- Data table area Start-->
    <div class="admin-dashone-data-table-area mg-b-40">
        <div class="container">
			<div class="row">
                <div class="col-lg-3">
					
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>Donors</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<?php
										require "config.php";
									$dash_donor="SELECT * FROM donor";
									$dash_donor_run=mysqli_query($con,$dash_donor);
									if($donor_total=mysqli_num_rows($dash_donor_run))
									{
										echo  "<h4>$donor_total</h4>";
									}
									else
									{
										echo  "<h4>no date</h4>";
									}
									
								?>
                                   
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline1"><canvas style="display: inline-block; width: 27px; height: 16px; vertical-align: top;" width="27" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range">
                                <p>Total Donors</p>
								
                                <span class="income-percentange">98% <i class="fa fa-bolt"></i></span>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>Request</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<?php
										
									$dash_request="SELECT * FROM request";
									$dash_request_run=mysqli_query($con,$dash_request);
									if($request_total=mysqli_num_rows($dash_request_run))
									{
										echo  "<h4>$request_total</h4>";
									}
									else
									{
										echo  "<h4>no date</h4>";
									}
									
								?>
                                   
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline6"><canvas style="display: inline-block; width: 56px; height: 16px; vertical-align: top;" width="56" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range order-cl">
                                <p>Total Request</p>
                                <span class="income-percentange">99.9% <i class="fa fa-level-up"></i></span>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>Bags</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<?php
									/*
									$dash_collection="SELECT  bags FROM collection";
									$dash_collection_run=mysqli_query($con,$dash_collection);
									while($res=mysqli_fetch_array($dash_collection_run)){
									$total += $res['bags'];
									
									}*/

								?>
								<?php /*echo  "<h4> $total</h4>";*/?>
								<h4> 100</h4>
								
                                   
								
								
                                   
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline2"><canvas style="display: inline-block; width: 39px; height: 16px; vertical-align: top;" width="39" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range visitor-cl">
                                <p>Total Bags</p>
                                <span class="income-percentange">55% <i class="fa fa-level-up"></i></span>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>Message</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<?php
									
									$dash_message="SELECT * FROM message";
									$dash_message_run=mysqli_query($con,$dash_message);
									if($message_total=mysqli_num_rows($dash_message_run))
									{
										echo  "<h4>$message_total</h4>";
									}
									else
									{
										echo  "<h4>no date</h4>";
									}
									
								?>
                                   
                                    
									
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline5"><canvas style="display: inline-block; width: 59px; height: 16px; vertical-align: top;" width="59" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range low-value-cl">
                                <p>Total Message</p>
                                <span class="income-percentange">33% <i class="fa fa-level-down"></i></span>
                            </div>
                            <div class="clear"></div>
                        </div>	
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- blood type -->
<h2><center>Available Blood per Group</center>	 </h2>
	<div class="admin-dashone-data-table-area mg-b-40">
        <div class="container">
			<div class="row">
                <div class="col-lg-3">
					
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>O+</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
									<h5>1</<h5> 
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline1"><canvas style="display: inline-block; width: 27px; height: 16px; vertical-align: top;" width="27" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range">
                                <p>Total </p>
						</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>O-</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								
                                <h5>1</<h5> 
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline6"><canvas style="display: inline-block; width: 56px; height: 16px; vertical-align: top;" width="56" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range order-cl">
                                <p>Total </p>
                               
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>A+</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<h5>1</<h5> 
								</div>
                                <div class="price-graph">
                                    <span id="sparkline2"><canvas style="display: inline-block; width: 39px; height: 16px; vertical-align: top;" width="39" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range visitor-cl">
                                <p>Total</p>
                               
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>A-</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								
                                   <h5>1</<h5>  
									
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline5"><canvas style="display: inline-block; width: 59px; height: 16px; vertical-align: top;" width="59" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range low-value-cl">
                                <p>Total </p>
                                
                            </div>
                            <div class="clear"></div>
                        </div>	
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="admin-dashone-data-table-area mg-b-40">
        <div class="container">
			<div class="row">
                <div class="col-lg-3">
					
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>B+</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<h5>1</<h5> 
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline1"><canvas style="display: inline-block; width: 27px; height: 16px; vertical-align: top;" width="27" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range">
                                <p>Total </p>
						</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>B-</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								
                                 <h5>1</<h5> 
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline6"><canvas style="display: inline-block; width: 56px; height: 16px; vertical-align: top;" width="56" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range order-cl">
                                <p>Total </p>
                               
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>AB+</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								<h5>1</<h5> 
								</div>
                                <div class="price-graph">
                                    <span id="sparkline2"><canvas style="display: inline-block; width: 39px; height: 16px; vertical-align: top;" width="39" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range visitor-cl">
                                <p>Total</p>
                               
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="income-dashone-total shadow-reset nt-mg-b-30">
                        <div class="income-title">
                            <div class="main-income-head">
                                <h2>AB-</h2>
                            </div>
                        </div>
                        <div class="income-dashone-pro">
                            <div class="income-rate-total">
                                <div class="price-adminpro-rate">
								
                                  <h5>1</<h5>  
									
                                </div>
                                <div class="price-graph">
                                    <span id="sparkline5"><canvas style="display: inline-block; width: 59px; height: 16px; vertical-align: top;" width="59" height="16"></canvas></span>
                                </div>
                            </div>
                            <div class="income-range low-value-cl">
                                <p>Total </p>
                                
                            </div>
                            <div class="clear"></div>
                        </div>	
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Data table area End-->
	<!-- footer strat-->
	<?php
		require "footer.php";
	?>
	<!-- footer end-->
    <!-- Color Switcher -->
    <div class="ec-colorswitcher sidebarmain">
        <a class="ec-handle btnclose" href="#"><i class="fa fa-cog" aria-hidden="true"></i></a>
        <h3>Style Switcher</h3>
        <div class="ec-switcherarea">
            <div class="base-color">
                <h6>Background Color</h6>
                <ul class="ec-switcher">
                    <li>
                        <a href="#" class="cs-color-1 styleswitch" data-rel="color-one"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-2 styleswitch" data-rel="color-two"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-3 styleswitch" data-rel="color-three"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-4 styleswitch" data-rel="color-four"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-5 styleswitch" data-rel="color-five"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-6 styleswitch" data-rel="color-six"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-7 styleswitch" data-rel="color-seven"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-8 styleswitch" data-rel="color-eight"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-9 styleswitch" data-rel="color-nine"></a>
                    </li>
                    <li>
                        <a href="#" class="cs-color-10 styleswitch" data-rel="color-ten"></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Color Switcher end -->
    <!-- jquery
        ============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- peity JS
        ============================================ -->
    <script src="js/peity/jquery.peity.min.js"></script>
    <script src="js/peity/peity-active.js"></script>
    <!-- sparkline JS
        ============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
        ============================================ -->
    <script src="js/flot/jquery.flot.js"></script>
    <script src="js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/flot/jquery.flot.spline.js"></script>
    <script src="js/flot/jquery.flot.resize.js"></script>
    <script src="js/flot/jquery.flot.pie.js"></script>
    <script src="js/flot/Chart.min.js"></script>
    <script src="js/flot/flot-active.js"></script>
    <!-- map JS
        ============================================ -->
    <script src="js/map/raphael.min.js"></script>
    <script src="js/map/jquery.mapael.js"></script>
    <script src="js/map/france_departments.js"></script>
    <script src="js/map/world_countries.js"></script>
    <script src="js/map/usa_states.js"></script>
    <script src="js/map/map-active.js"></script>
    <!-- data table JS
        ============================================ -->
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!-- switcher JS
        ============================================ -->
    <script src="js/switcher/styleswitch.js"></script>
    <script src="js/switcher/switch-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="js/main.js"></script>
</body>

</html>